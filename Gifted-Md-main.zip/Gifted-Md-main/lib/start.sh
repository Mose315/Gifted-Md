while true
do
echo "Starting Gifted-Md!"
node smd.js
done

     
   
     
