<h1 align="center"> ɢɪғᴛᴇᴅ ᴍᴅ Version 2.5.0 </h1> 
 <br>



<p align="center"> Introducing ɢɪғᴛᴇᴅ ʙᴏᴛ v2.5.0, It is designed to bring a whole new level of excitement to your boring WhatsApp use. </p>

<p align="center">
  <a href="https://github.com/mouricedevs/Gifted-Md">
    <img alt="Gifted docs" height="300" src="https://telegra.ph/file/54efddccf41281ad7ec51.jpg">
  </a>
</p>
    
   
   
<p align="center">
  <a href="https://wa.me/+254728782591?text=Hi+Bro--+I+Need+Help.+I've+messaged+you+from+ɢɪғᴛᴇᴅ ʙᴏᴛ+Repo" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/ Whatsapp -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
 
  <a aria-label="ɢɪғᴛᴇᴅ ʙᴏᴛ v.2.5.0 is free to use" href="https://github.com/mouricedevs/Gifted-Md" target="_blank">
    <img alt="GiftedTech" src="https://img.shields.io/youtube/channel/subscribers/UCU071AMRqcd5mfTdCgJFwPg" target="_blank" />
  </a>

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{mouricedevs}/count.svg" alt="ɢɪғᴛᴇᴅ ᴍᴅ :: Visitor's Count" /></p>

---




<p align="center"> ɢɪғᴛᴇᴅ ᴍᴅ V.2.5.0 uses
  <a href="https://github.com/adiwajshing/Baileys">Multi-Device Baileys.</a>
</p>
<p align="center">
  <img title="Whatsapp-Bot-Javascript" src="https://img.shields.io/badge/Javascript-363303?style=for-the-badge&logo=javascript&logoColor=c6c631"></img>
</p>

---

<p align="center">
  <a href="https://github.com/mouricedevs/Gifted-Md"><b>Gifted-Md V.2.5.0</b></a> Support Deploy On...
</p>

<p align="center">
  <a href="https://github.com/mouricedevs/Gifted-Md/blob/main/temp/deploy-on-vps.md"><img src="https://img.shields.io/badge/self hosting-3d1513?style=for-the-badge&logo=serverless&logoColor=FD5750"></a>
  <a href="https://railway.app/template/89ED3x?referralCode=WiTucG"><img src="https://img.shields.io/badge/railway-3e164f?style=for-the-badge&logo=railway&logoColor=0B0D0E"></a>
</p>
<p align="center">
  <a href="https://deploy-gifted-md.vercel.app"><img src="https://img.shields.io/badge/heroku-9d7acc?style=for-the-badge&logo=heroku&logoColor=430098"></a>
  <a href="https://replit.com/github.com/mouricedevs/Gifted-Md"><img src="https://img.shields.io/badge/replit-253c99?style=for-the-badge&logo=replit&logoColor=F26207"></a>
  <a href="https://app.koyeb.com/apps/deploy?type=git&repository=github.com/mouricedevs/Gifted-Md&branch=main&env[SESSION_ID]&env[OWNER_NUMBER]=254762016957&env[MONGODB_URI]&&env[OWNER_NAME]=ɢɪғᴛᴇᴅ ᴛᴇᴄʜ&env[KOYEB_API]&env[PREFIX]=.&env[WAPRESENCE]&env[AUTO_READ_STATUS]=true&env[DISABLE_PM]=false&env[PACK_AUTHER]=whatsapp+bot&env[PACK_NAME]=ɢɪғᴛᴇᴅ ᴛᴇᴄʜ&env[STYLE]=0&env[MODE]=private&env[READ_MESSAGE]=false&env[THEME]=GIFTED&env[WARN_COUNT]=3&env[BLOCK_JID]=null&env[TIME_ZONE]=Africa/Nairobi&name=gifted-tech&env[KOYEB_NAME]=gifted-md&env[SUDO]=null&env[THUMB_IMAGE]=https://telegra.ph/file/54efddccf41281ad7ec51.jpg"><img src="https://img.shields.io/badge/koyeb-033604?style=for-the-badge&logo=koyeb&logoColor=white"></a>
</p>
<p align="center">
  <a href="https://youtu.be/3NdJb6_1cJM"><img src="https://img.shields.io/badge/CodeSpace-green?colorA=%23ff000&colorB=%23017e40&style=for-the-badge&logo=git&logoColor=white"></a>
</p>
<p align="center">Need help? please create an <a href="https://github.com/mouricedevs/Gifted-Md/issues">issue</a></p>



## Some of Gifted-Md Bot Games:
---
1. ***Connect Four Game(cfg).***
2.  ***Tic Tac Toe.***
3.  ***Number Guessing Game(ngg).***
4.  ***Word chain Game(wcg).***
5.  ***Hidden Card Game(hcg).***
6.  ***Rolling Dice.***
7.  ***Character Guessing Game(cgg).***
8.  ***Capital of City Finding(ccf).***
##

---

 <h3>Gifted-MD V.2.5.0 Stats</h3>

![Giftd-mdV2 Stats](https://github-readme-stats.vercel.app/api/pin/?username=mouricedevs&repo=Gifted-Md&show_owner=true&theme=dark)




    
   
## Gifted-Md V.2.5.0 Deployment Methods
---
1.  ***Fork Repo [`CLICK HERE`](https://github.com/mouricedevs/Gifted-Md/fork) (A MUST) and `Star ⭐ Repository` for Courage.***
2.  ***Get `SESSION ID`  [`BY CLICKING HERE`](https://web.giftedtechnexus.co.ke) Supports Both QR SCAN And Pair Code And then `Go-to Whatapp>Three dots>Linked Devices`***
3. ***Deploy on [`HEROKU`](https://deploy-gifted-md.vercel.app/)***
4.  ***Deploy FREE on `Codespace,` First see [`Codespace tutorial`](https://youtu.be/3NdJb6_1cJM)***
5.  ***Deploy on [`Replit`](https://replit.com/github.com/mouricedevs/Gifted-Md)***
6.  ***Deploy on [`Railway`](https://railway.app/template/89ED3x?referralCode=WiTucG)***
7.  ***Deploy on [`Koyeb`](https://app.koyeb.com/apps/deploy?type=git&repository=github.com/mouricedevs/Gifted-Md&branch=main&env[SESSION_ID]&env[OWNER_NUMBER]=254762016957&env[MONGODB_URI]&&env[OWNER_NAME]=ɢɪғᴛᴇᴅᴛᴇᴄʜ&env[KOYEB_API]&env[PREFIX]=.&env[WAPRESENCE]&env[AUTO_READ_STATUS]=true&env[DISABLE_PM]=true&env[PACK_AUTHER]=whatsapp+bot&env[PACK_NAME]=ɢɪғᴛᴇᴅᴛᴇᴄʜ&env[STYLE]=0&env[MODE]=private&env[READ_MESSAGE]=false&env[THEME]=GIFTED&env[WARN_COUNT]=3&env[BLOCK_JID]=null&env[TIME_ZONE]=Africa/Nairobi&name=suhail-md&env[KOYEB_NAME]=gifted-md&env[SUDO]=null&env[THUMB_IMAGE]=https://telegra.ph/file/54efddccf41281ad7ec51.jpg)***

##
---


- Star ⭐ repo if you like this bot.
- If any problem, then [`Whatsapp Me Here`](https://wa.me/message/NHCZC5DSOEUXB1)


### I Am
- [Gifted Tech](https://github.com/mouricedevs) 

---
### Credits to:
- [Suhail Ser](https://github.com/SuhailTechInfo) for the Base Bot
- [Astropeda Team](https://github.com/Astropeda) for new menu design and some cmds
- [France King](https://github.com/franceking1) for our long-lasting brotherhood


---


<h2 align="center">  NOTICE
</h2>
   
## 
- *Gifted-Md is not made by `WhatsApp Inc.` Sometimes or misusing the bot might `ban` your `WhatsApp account!`*
- *In that case, I'm not responsible for banning your account.*
- *Use Gifted-Md at your own risk by keeping this warning in mind.*
- [`Deploy on Heroku`](https://deploy-gifted-md.vercel.app)
